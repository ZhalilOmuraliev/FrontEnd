let nam = prompt("Введите ИМЯ: ", "")
let nam2 = prompt("Введите Фамилию: ", "")

alert(nam + nam2)

let number = prompt("Введите первое число для сложения: ", "");
let number2 = prompt("Введите второе число для сложения: ", "");

alert((Number(number)) + (Number(number2)))


let number3 = prompt("Введите первое число для умножения: ", "");
let number4 = prompt("Введите второе число для умножения: ", "");

alert((Number(number3)) * (Number(number4)))


