let log = prompt("Введите логин: ");
let password = prompt("Введите пароль: ");

if (log == "login"){
    alert(let)
    if (password = "password"){
        alert("Welcome")
    }else{
        alert("Пароль не верный")
    }
}else{
    alert("Логин не верный")
}


function func(){
    var num1 = Number(document.getElementById("num1").value);
    var num2 = Number(document.getElementById("num2").value);
    var result = num1 + num2;

    document.getElementById("result").innerHTML = result;
    }